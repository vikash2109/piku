def activity01(num1):
	'''Determine if an input number is Even or Odd'''
    return
		
def activity02(iv_one, iv_two):
	'''Return the sum of two input values'''
	return

def activity03(num_list):
	'''Given a list of integers, count how many are even'''
	return
	
def activity04(input_string):
	'''Return the input string, backward'''
	return
	
