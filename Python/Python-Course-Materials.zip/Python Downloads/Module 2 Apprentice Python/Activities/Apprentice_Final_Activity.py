import operator

saved_string = ''

def remove_letter(): #Remove a selected letter from a string
    return

def num_compare(): #Compare 2 numbers to determine the larger
    return

def print_string(): #Print the previously stored string
    return

def calculator(): #Basic Calculator (addition, subtraction, multiplication, division)
    return

def accept_and_store(): #Accept and store a string
    return

def main(): #menu goes here
    return

main()
