import struct
import socket
import binascii
import os

def main():


main()
